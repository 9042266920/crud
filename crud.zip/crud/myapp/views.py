from .models import MyModel
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse

# Common HTML header
def get_custom_header():
    header = """
    <h1>KAMARAJ COLLEGE OF ENGINEERING AND TECHNOLOGY</h1>
    <h2>WEB APPLICATION USING DJANGO FRAMEWORK</h2>
    <h3>DEVI PRABHA.S 22UIT066</h3>
    <h3>CONNECTING DATABASE USING SQLITE</h3>
    <hr>
    """
    return header

def create1(request):
    if request.method == 'POST':
        product_name = request.POST.get('product_name')
        price = request.POST.get('price')
        quantity = request.POST.get('quantity')
        description = request.POST.get('description')
        MyModel.objects.create(product_name=product_name, price=price, quantity=quantity, description=description)
        return HttpResponse(get_custom_header() + "Product created successfully")
    return render(request, 'create.html')

def read(request):
    objects = MyModel.objects.all()
    return render(request, 'read.html', {'objects': objects})

def update(request, pk):
    instance = get_object_or_404(MyModel, pk=pk)
    if request.method == 'POST':
        product_name = request.POST.get('product_name')
        price = request.POST.get('price')
        quantity = request.POST.get('quantity')
        description = request.POST.get('description')
        instance.product_name = product_name
        instance.price = price
        instance.quantity = quantity
        instance.description = description
        instance.save()
        return HttpResponse(get_custom_header() + "Product updated successfully")
    return render(request, 'update.html', {'instance': instance})

def delete(request, pk):
    instance = get_object_or_404(MyModel, pk=pk)
    if request.method == 'POST':
        instance.delete()
        return HttpResponse(get_custom_header() + f"Product {instance.product_name} deleted successfully")
    return render(request, 'delete.html', {'instance': instance})
